/**
 * 
 */
package ProblemALGGRD002a;

/**
 * @author Administrator
 *
 */
public class ALG_GRD_002a {



       
        

	static void sum(int n, int q){
	    int i = q;
	    int sum, tmp=0;
	    while(i < n){
	        sum = i * (i+1) / 2;
	        System.out.println(String.format("Sum from %d to %d : %d", i-q+1 , i, sum - tmp));
	        System.out.println(String.format("Sum from %d to %d : %d", 1, i, sum));
	        tmp = sum;
	        i += q;
	    }
	    {
			int totalSum = 0;
			int batchSum = 0;

			for (int i = 1; i <= n; i++) {
			    totalSum += i;
			    batchSum += i;
			    if (i % batchSum == 0) {
			        System.out.println("Sum from " + (i - batchSum + 1) + " to " + i + ":" + batchSum);
			        System.out.println("Sum from 1 to " + i + ":" + totalSum);
			        batchSum = 0;
			    }
			}
	    }
